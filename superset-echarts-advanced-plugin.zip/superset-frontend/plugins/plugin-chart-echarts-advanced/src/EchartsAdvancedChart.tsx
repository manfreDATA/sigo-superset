Contents of EchartsAdvancedChart.tsx
