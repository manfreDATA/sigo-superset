Contents of plugin.ts
