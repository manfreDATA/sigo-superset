Contents of transformProps.ts
