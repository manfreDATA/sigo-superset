Contents of README.txt
